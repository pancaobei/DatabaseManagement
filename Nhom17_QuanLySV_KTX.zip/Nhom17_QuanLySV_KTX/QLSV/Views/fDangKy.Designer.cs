﻿
namespace QLSV
{
    partial class fDangKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDangKy = new System.Windows.Forms.Button();
            this.cbSoKy = new System.Windows.Forms.ComboBox();
            this.cbMaPhong = new System.Windows.Forms.ComboBox();
            this.cbMaToa = new System.Windows.Forms.ComboBox();
            this.cbGioiTinh = new System.Windows.Forms.ComboBox();
            this.dtpkNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtCCCD = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtMaSv = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAnh = new System.Windows.Forms.Button();
            this.txtAnh = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.ODL = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDangKy
            // 
            this.btnDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKy.Location = new System.Drawing.Point(539, 256);
            this.btnDangKy.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(182, 46);
            this.btnDangKy.TabIndex = 27;
            this.btnDangKy.Text = "Đăng Ký";
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // cbSoKy
            // 
            this.cbSoKy.FormattingEnabled = true;
            this.cbSoKy.Location = new System.Drawing.Point(539, 210);
            this.cbSoKy.Margin = new System.Windows.Forms.Padding(2);
            this.cbSoKy.Name = "cbSoKy";
            this.cbSoKy.Size = new System.Drawing.Size(182, 21);
            this.cbSoKy.TabIndex = 26;
            // 
            // cbMaPhong
            // 
            this.cbMaPhong.FormattingEnabled = true;
            this.cbMaPhong.Location = new System.Drawing.Point(539, 168);
            this.cbMaPhong.Margin = new System.Windows.Forms.Padding(2);
            this.cbMaPhong.Name = "cbMaPhong";
            this.cbMaPhong.Size = new System.Drawing.Size(182, 21);
            this.cbMaPhong.TabIndex = 25;
            // 
            // cbMaToa
            // 
            this.cbMaToa.FormattingEnabled = true;
            this.cbMaToa.Location = new System.Drawing.Point(539, 124);
            this.cbMaToa.Margin = new System.Windows.Forms.Padding(2);
            this.cbMaToa.Name = "cbMaToa";
            this.cbMaToa.Size = new System.Drawing.Size(182, 21);
            this.cbMaToa.TabIndex = 24;
            this.cbMaToa.SelectedIndexChanged += new System.EventHandler(this.cbMaToa_SelectedIndexChanged);
            // 
            // cbGioiTinh
            // 
            this.cbGioiTinh.FormattingEnabled = true;
            this.cbGioiTinh.Location = new System.Drawing.Point(151, 167);
            this.cbGioiTinh.Margin = new System.Windows.Forms.Padding(2);
            this.cbGioiTinh.Name = "cbGioiTinh";
            this.cbGioiTinh.Size = new System.Drawing.Size(182, 21);
            this.cbGioiTinh.TabIndex = 23;
            this.cbGioiTinh.SelectedIndexChanged += new System.EventHandler(this.cbGioiTinh_SelectedIndexChanged);
            // 
            // dtpkNgaySinh
            // 
            this.dtpkNgaySinh.Location = new System.Drawing.Point(151, 125);
            this.dtpkNgaySinh.Margin = new System.Windows.Forms.Padding(2);
            this.dtpkNgaySinh.Name = "dtpkNgaySinh";
            this.dtpkNgaySinh.Size = new System.Drawing.Size(182, 20);
            this.dtpkNgaySinh.TabIndex = 22;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(151, 213);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(182, 20);
            this.txtDiaChi.TabIndex = 21;
            this.txtDiaChi.Text = "Hòn Đất";
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(539, 37);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(2);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(182, 20);
            this.txtSDT.TabIndex = 20;
            this.txtSDT.Text = "0336757217";
            this.txtSDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSDT_KeyPress);
            // 
            // txtCCCD
            // 
            this.txtCCCD.Location = new System.Drawing.Point(539, 84);
            this.txtCCCD.Margin = new System.Windows.Forms.Padding(2);
            this.txtCCCD.Name = "txtCCCD";
            this.txtCCCD.Size = new System.Drawing.Size(182, 20);
            this.txtCCCD.TabIndex = 19;
            this.txtCCCD.Text = "091202012357";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(151, 81);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(2);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(182, 20);
            this.txtHoTen.TabIndex = 18;
            this.txtHoTen.Text = "Hải Dương";
            // 
            // txtMaSv
            // 
            this.txtMaSv.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtMaSv.Location = new System.Drawing.Point(151, 37);
            this.txtMaSv.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaSv.Name = "txtMaSv";
            this.txtMaSv.Size = new System.Drawing.Size(182, 20);
            this.txtMaSv.TabIndex = 17;
            this.txtMaSv.Text = "20142482";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(43, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "Mã Sinh Viên:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(43, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Họ và Tên:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(431, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "CCCD:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(43, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 20);
            this.label4.TabIndex = 31;
            this.label4.Text = "Giới tính:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(43, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 20);
            this.label5.TabIndex = 32;
            this.label5.Text = "Ngày Sinh:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(43, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 20);
            this.label6.TabIndex = 33;
            this.label6.Text = "Địa Chỉ";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(431, 174);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 20);
            this.label8.TabIndex = 38;
            this.label8.Text = "Mã Phòng:";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(431, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 20);
            this.label9.TabIndex = 37;
            this.label9.Text = "Số Kỳ Ở:";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(431, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 20);
            this.label11.TabIndex = 35;
            this.label11.Text = "Mã Tòa:";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(431, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 20);
            this.label12.TabIndex = 34;
            this.label12.Text = "Số Điện thoại:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 426);
            this.panel1.TabIndex = 39;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.btnAnh);
            this.panel3.Controls.Add(this.txtAnh);
            this.panel3.Controls.Add(this.txtMaSv);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.btnDangKy);
            this.panel3.Controls.Add(this.cbSoKy);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txtHoTen);
            this.panel3.Controls.Add(this.cbMaPhong);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtCCCD);
            this.panel3.Controls.Add(this.cbMaToa);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtSDT);
            this.panel3.Controls.Add(this.cbGioiTinh);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.txtDiaChi);
            this.panel3.Controls.Add(this.dtpkNgaySinh);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(6, 75);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(765, 351);
            this.panel3.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(43, 258);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 20);
            this.label10.TabIndex = 41;
            this.label10.Text = "Ảnh: ";
            // 
            // btnAnh
            // 
            this.btnAnh.Location = new System.Drawing.Point(275, 256);
            this.btnAnh.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnh.Name = "btnAnh";
            this.btnAnh.Size = new System.Drawing.Size(56, 19);
            this.btnAnh.TabIndex = 40;
            this.btnAnh.Text = "Chọn ảnh";
            this.btnAnh.UseVisualStyleBackColor = true;
            this.btnAnh.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtAnh
            // 
            this.txtAnh.Location = new System.Drawing.Point(151, 256);
            this.txtAnh.Margin = new System.Windows.Forms.Padding(2);
            this.txtAnh.Name = "txtAnh";
            this.txtAnh.Size = new System.Drawing.Size(121, 20);
            this.txtAnh.TabIndex = 39;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(6, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(770, 66);
            this.panel2.TabIndex = 40;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Yellow;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(762, 66);
            this.label7.TabIndex = 0;
            this.label7.Text = "Đăng Ký Ở Ký Túc Xá Khu B";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ODL
            // 
            this.ODL.FileName = "openFileDialog1";
            // 
            // fDangKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "fDangKy";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.ComboBox cbSoKy;
        private System.Windows.Forms.ComboBox cbMaPhong;
        private System.Windows.Forms.ComboBox cbMaToa;
        private System.Windows.Forms.ComboBox cbGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpkNgaySinh;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.TextBox txtCCCD;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtMaSv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnAnh;
        private System.Windows.Forms.TextBox txtAnh;
        private System.Windows.Forms.OpenFileDialog ODL;
    }
}

