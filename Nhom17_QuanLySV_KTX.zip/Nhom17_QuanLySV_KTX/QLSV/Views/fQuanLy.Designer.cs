﻿namespace QLSV.Views
{
    partial class fQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.tbThongTin = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtmaKL = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.btnXoaKL = new System.Windows.Forms.Button();
            this.btnThemKL = new System.Windows.Forms.Button();
            this.txtMaToaKL = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.dtpNgayViPham = new System.Windows.Forms.DateTimePicker();
            this.label40 = new System.Windows.Forms.Label();
            this.txtLoiViPham = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtMaKyLuat = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtMaSVKL = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvKyLuat = new System.Windows.Forms.DataGridView();
            this.label36 = new System.Windows.Forms.Label();
            this.tbHDTP = new System.Windows.Forms.TabPage();
            this.label30 = new System.Windows.Forms.Label();
            this.grpHopDong = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboLoaiTKHD = new System.Windows.Forms.ComboBox();
            this.txtTimKiemHD = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.tabQLDN = new System.Windows.Forms.TabPage();
            this.grpHoaDon = new System.Windows.Forms.GroupBox();
            this.cboLoai = new System.Windows.Forms.ComboBox();
            this.btnTimKiemHD = new System.Windows.Forms.Button();
            this.btnXacNhanDT = new System.Windows.Forms.Button();
            this.btnXoaHD = new System.Windows.Forms.Button();
            this.btnTaoHD = new System.Windows.Forms.Button();
            this.cboThangHD = new System.Windows.Forms.ComboBox();
            this.txtTrangThai = new System.Windows.Forms.TextBox();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.txtMaPhongHD = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.grpTienNuoc = new System.Windows.Forms.GroupBox();
            this.btnCD = new System.Windows.Forms.Button();
            this.btnTimKiemTN = new System.Windows.Forms.Button();
            this.cboThangTN = new System.Windows.Forms.ComboBox();
            this.btnXoaTN = new System.Windows.Forms.Button();
            this.btnThemTN = new System.Windows.Forms.Button();
            this.txtTienNuoc = new System.Windows.Forms.TextBox();
            this.txtNuocCuoiThang = new System.Windows.Forms.TextBox();
            this.txtNuocDauThang = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMaPhongTN = new System.Windows.Forms.TextBox();
            this.dgvTienNuoc = new System.Windows.Forms.DataGridView();
            this.grpTienDien = new System.Windows.Forms.GroupBox();
            this.btnTimKiemTD = new System.Windows.Forms.Button();
            this.cboThangTD = new System.Windows.Forms.ComboBox();
            this.btnXoaTD = new System.Windows.Forms.Button();
            this.btnThemTD = new System.Windows.Forms.Button();
            this.txtTienDien = new System.Windows.Forms.TextBox();
            this.txtDienCuoiThang = new System.Windows.Forms.TextBox();
            this.txtDienDauThang = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMaPhongTD = new System.Windows.Forms.TextBox();
            this.dgvTienDien = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.tbQLSV = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grpDanhSach = new System.Windows.Forms.GroupBox();
            this.dgvSinhVien = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grpTTSV = new System.Windows.Forms.GroupBox();
            this.btnDuyet = new System.Windows.Forms.Button();
            this.btnDSduyet = new System.Windows.Forms.Button();
            this.txtTaiKhoan = new System.Windows.Forms.Button();
            this.grbTimKiem = new System.Windows.Forms.GroupBox();
            this.cboLoaiTimKiem = new System.Windows.Forms.ComboBox();
            this.txtTimKiem = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.txtSdt = new System.Windows.Forms.TextBox();
            this.txtMaToa = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtGT = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtCCCD = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtMSV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabKyLuat = new System.Windows.Forms.TabControl();
            this.tpTTTaiKhoan = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSuaTTQL = new System.Windows.Forms.Button();
            this.btnDoiMatKhau = new System.Windows.Forms.Button();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.txtToaQL = new System.Windows.Forms.TextBox();
            this.txtTenQL = new System.Windows.Forms.TextBox();
            this.txtMaQL = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtMaPhongp = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtLoaiPhong = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtMaToap = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtSoNguoiO = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtTKPhong = new System.Windows.Forms.TextBox();
            this.Max = new System.Windows.Forms.Label();
            this.btnXoaP = new System.Windows.Forms.Button();
            this.btnThemP = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.D = new System.Windows.Forms.Label();
            this.cboThangTT = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtTongTDN = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtTienDaThu = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtTienConLai = new System.Windows.Forms.TextBox();
            this.tbThongTin.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKyLuat)).BeginInit();
            this.tbHDTP.SuspendLayout();
            this.grpHopDong.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            this.tabQLDN.SuspendLayout();
            this.grpHoaDon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.grpTienNuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNuoc)).BeginInit();
            this.grpTienDien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienDien)).BeginInit();
            this.tbQLSV.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grpDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSinhVien)).BeginInit();
            this.panel1.SuspendLayout();
            this.grpTTSV.SuspendLayout();
            this.grbTimKiem.SuspendLayout();
            this.tabKyLuat.SuspendLayout();
            this.tpTTTaiKhoan.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbThongTin
            // 
            this.tbThongTin.Controls.Add(this.groupBox3);
            this.tbThongTin.Controls.Add(this.groupBox2);
            this.tbThongTin.Controls.Add(this.label36);
            this.tbThongTin.Location = new System.Drawing.Point(4, 25);
            this.tbThongTin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbThongTin.Name = "tbThongTin";
            this.tbThongTin.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbThongTin.Size = new System.Drawing.Size(1387, 769);
            this.tbThongTin.TabIndex = 3;
            this.tbThongTin.Text = "Kỷ Luật";
            this.tbThongTin.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.btnXoaKL);
            this.groupBox3.Controls.Add(this.btnThemKL);
            this.groupBox3.Controls.Add(this.txtMaToaKL);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.dtpNgayViPham);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.txtLoiViPham);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.txtMaKyLuat);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.txtMaSVKL);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Location = new System.Drawing.Point(3, 75);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(483, 679);
            this.groupBox3.TabIndex = 182;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông Tin";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtmaKL);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox4.Location = new System.Drawing.Point(5, 430);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(476, 249);
            this.groupBox4.TabIndex = 155;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm Kiếm";
            // 
            // txtmaKL
            // 
            this.txtmaKL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaKL.Location = new System.Drawing.Point(172, 30);
            this.txtmaKL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtmaKL.Name = "txtmaKL";
            this.txtmaKL.Size = new System.Drawing.Size(192, 28);
            this.txtmaKL.TabIndex = 150;
            this.txtmaKL.TextChanged += new System.EventHandler(this.txtmaKL_TextChanged);
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(5, 30);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(144, 39);
            this.label42.TabIndex = 142;
            this.label42.Text = "Mã Sinh Viên";
            // 
            // btnXoaKL
            // 
            this.btnXoaKL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaKL.Location = new System.Drawing.Point(252, 345);
            this.btnXoaKL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaKL.Name = "btnXoaKL";
            this.btnXoaKL.Size = new System.Drawing.Size(115, 43);
            this.btnXoaKL.TabIndex = 154;
            this.btnXoaKL.Text = "Xóa";
            this.btnXoaKL.UseVisualStyleBackColor = true;
            this.btnXoaKL.Click += new System.EventHandler(this.btnXoaKL_Click);
            // 
            // btnThemKL
            // 
            this.btnThemKL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemKL.Location = new System.Drawing.Point(117, 345);
            this.btnThemKL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThemKL.Name = "btnThemKL";
            this.btnThemKL.Size = new System.Drawing.Size(115, 43);
            this.btnThemKL.TabIndex = 153;
            this.btnThemKL.Text = "Thêm";
            this.btnThemKL.UseVisualStyleBackColor = true;
            this.btnThemKL.Click += new System.EventHandler(this.btnThemKL_Click);
            // 
            // txtMaToaKL
            // 
            this.txtMaToaKL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaToaKL.Location = new System.Drawing.Point(179, 165);
            this.txtMaToaKL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaToaKL.Name = "txtMaToaKL";
            this.txtMaToaKL.ReadOnly = true;
            this.txtMaToaKL.Size = new System.Drawing.Size(188, 28);
            this.txtMaToaKL.TabIndex = 152;
            // 
            // label41
            // 
            this.label41.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(1, 162);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(155, 30);
            this.label41.TabIndex = 151;
            this.label41.Text = "Mã Tòa";
            // 
            // dtpNgayViPham
            // 
            this.dtpNgayViPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayViPham.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayViPham.Location = new System.Drawing.Point(179, 266);
            this.dtpNgayViPham.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpNgayViPham.Name = "dtpNgayViPham";
            this.dtpNgayViPham.Size = new System.Drawing.Size(188, 28);
            this.dtpNgayViPham.TabIndex = 150;
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(1, 266);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(155, 30);
            this.label40.TabIndex = 149;
            this.label40.Text = "Ngày VI Phạm";
            // 
            // txtLoiViPham
            // 
            this.txtLoiViPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoiViPham.Location = new System.Drawing.Point(179, 215);
            this.txtLoiViPham.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLoiViPham.Name = "txtLoiViPham";
            this.txtLoiViPham.Size = new System.Drawing.Size(188, 28);
            this.txtLoiViPham.TabIndex = 148;
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(1, 213);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(155, 30);
            this.label39.TabIndex = 147;
            this.label39.Text = "Lỗi Vi Phạm";
            // 
            // txtMaKyLuat
            // 
            this.txtMaKyLuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKyLuat.Location = new System.Drawing.Point(179, 62);
            this.txtMaKyLuat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaKyLuat.Name = "txtMaKyLuat";
            this.txtMaKyLuat.Size = new System.Drawing.Size(188, 28);
            this.txtMaKyLuat.TabIndex = 146;
            // 
            // label38
            // 
            this.label38.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(1, 60);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(155, 30);
            this.label38.TabIndex = 145;
            this.label38.Text = "Mã Kỹ Luật";
            // 
            // txtMaSVKL
            // 
            this.txtMaSVKL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaSVKL.Location = new System.Drawing.Point(179, 113);
            this.txtMaSVKL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaSVKL.Name = "txtMaSVKL";
            this.txtMaSVKL.Size = new System.Drawing.Size(188, 28);
            this.txtMaSVKL.TabIndex = 144;
            // 
            // label37
            // 
            this.label37.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(1, 111);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(155, 25);
            this.label37.TabIndex = 143;
            this.label37.Text = "Mã Sinh Viên";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvKyLuat);
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(485, 75);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(899, 686);
            this.groupBox2.TabIndex = 181;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh Sách";
            // 
            // dgvKyLuat
            // 
            this.dgvKyLuat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKyLuat.Location = new System.Drawing.Point(5, 15);
            this.dgvKyLuat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvKyLuat.Name = "dgvKyLuat";
            this.dgvKyLuat.ReadOnly = true;
            this.dgvKyLuat.RowHeadersWidth = 51;
            this.dgvKyLuat.RowTemplate.Height = 24;
            this.dgvKyLuat.Size = new System.Drawing.Size(905, 665);
            this.dgvKyLuat.TabIndex = 0;
            this.dgvKyLuat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKyLuat_CellClick);
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Yellow;
            this.label36.Location = new System.Drawing.Point(-1, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(1388, 69);
            this.label36.TabIndex = 180;
            this.label36.Text = "Kỷ Luật";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbHDTP
            // 
            this.tbHDTP.Controls.Add(this.label30);
            this.tbHDTP.Controls.Add(this.grpHopDong);
            this.tbHDTP.Location = new System.Drawing.Point(4, 25);
            this.tbHDTP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbHDTP.Name = "tbHDTP";
            this.tbHDTP.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbHDTP.Size = new System.Drawing.Size(1387, 769);
            this.tbHDTP.TabIndex = 2;
            this.tbHDTP.Text = "Hợp Đồng Thuê Phòng";
            this.tbHDTP.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Yellow;
            this.label30.Location = new System.Drawing.Point(5, 2);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(1388, 69);
            this.label30.TabIndex = 155;
            this.label30.Text = "Hợp Đồng";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // grpHopDong
            // 
            this.grpHopDong.Controls.Add(this.groupBox1);
            this.grpHopDong.Controls.Add(this.dgvHopDong);
            this.grpHopDong.Location = new System.Drawing.Point(3, 75);
            this.grpHopDong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHopDong.Name = "grpHopDong";
            this.grpHopDong.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHopDong.Size = new System.Drawing.Size(1375, 311);
            this.grpHopDong.TabIndex = 1;
            this.grpHopDong.TabStop = false;
            this.grpHopDong.Text = "Hợp Đồng";
            this.grpHopDong.Enter += new System.EventHandler(this.grpHopDong_Enter);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboLoaiTKHD);
            this.groupBox1.Controls.Add(this.txtTimKiemHD);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox1.Location = new System.Drawing.Point(823, 21);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(552, 284);
            this.groupBox1.TabIndex = 154;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm";
            // 
            // cboLoaiTKHD
            // 
            this.cboLoaiTKHD.FormattingEnabled = true;
            this.cboLoaiTKHD.Items.AddRange(new object[] {
            "Mã Phòng",
            "Mã Sinh Viên"});
            this.cboLoaiTKHD.Location = new System.Drawing.Point(331, 34);
            this.cboLoaiTKHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboLoaiTKHD.Name = "cboLoaiTKHD";
            this.cboLoaiTKHD.Size = new System.Drawing.Size(129, 24);
            this.cboLoaiTKHD.TabIndex = 151;
            this.cboLoaiTKHD.SelectedIndexChanged += new System.EventHandler(this.cboLoaiTKHD_SelectedIndexChanged);
            // 
            // txtTimKiemHD
            // 
            this.txtTimKiemHD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiemHD.Location = new System.Drawing.Point(133, 31);
            this.txtTimKiemHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTimKiemHD.Name = "txtTimKiemHD";
            this.txtTimKiemHD.Size = new System.Drawing.Size(192, 28);
            this.txtTimKiemHD.TabIndex = 150;
            this.txtTimKiemHD.TextChanged += new System.EventHandler(this.txtTimKiemHD_TextChanged);
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(5, 30);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 30);
            this.label29.TabIndex = 142;
            this.label29.Text = "Thông Tin";
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Location = new System.Drawing.Point(5, 21);
            this.dgvHopDong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.RowHeadersWidth = 51;
            this.dgvHopDong.RowTemplate.Height = 24;
            this.dgvHopDong.Size = new System.Drawing.Size(811, 284);
            this.dgvHopDong.TabIndex = 0;
            // 
            // tabQLDN
            // 
            this.tabQLDN.Controls.Add(this.grpHoaDon);
            this.tabQLDN.Controls.Add(this.grpTienNuoc);
            this.tabQLDN.Controls.Add(this.grpTienDien);
            this.tabQLDN.Controls.Add(this.label10);
            this.tabQLDN.Location = new System.Drawing.Point(4, 25);
            this.tabQLDN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabQLDN.Name = "tabQLDN";
            this.tabQLDN.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabQLDN.Size = new System.Drawing.Size(1387, 769);
            this.tabQLDN.TabIndex = 1;
            this.tabQLDN.Text = "Quản Lý Điện Nước";
            this.tabQLDN.UseVisualStyleBackColor = true;
            // 
            // grpHoaDon
            // 
            this.grpHoaDon.Controls.Add(this.groupBox8);
            this.grpHoaDon.Controls.Add(this.cboLoai);
            this.grpHoaDon.Controls.Add(this.btnTimKiemHD);
            this.grpHoaDon.Controls.Add(this.btnXacNhanDT);
            this.grpHoaDon.Controls.Add(this.btnXoaHD);
            this.grpHoaDon.Controls.Add(this.btnTaoHD);
            this.grpHoaDon.Controls.Add(this.cboThangHD);
            this.grpHoaDon.Controls.Add(this.txtTrangThai);
            this.grpHoaDon.Controls.Add(this.txtTongTien);
            this.grpHoaDon.Controls.Add(this.txtMaPhongHD);
            this.grpHoaDon.Controls.Add(this.label24);
            this.grpHoaDon.Controls.Add(this.label25);
            this.grpHoaDon.Controls.Add(this.label26);
            this.grpHoaDon.Controls.Add(this.label27);
            this.grpHoaDon.Controls.Add(this.label28);
            this.grpHoaDon.Controls.Add(this.txtMaHD);
            this.grpHoaDon.Controls.Add(this.dgvHoaDon);
            this.grpHoaDon.Location = new System.Drawing.Point(11, 402);
            this.grpHoaDon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHoaDon.Name = "grpHoaDon";
            this.grpHoaDon.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHoaDon.Size = new System.Drawing.Size(1371, 363);
            this.grpHoaDon.TabIndex = 4;
            this.grpHoaDon.TabStop = false;
            this.grpHoaDon.Text = "Hóa Đơn";
            // 
            // cboLoai
            // 
            this.cboLoai.FormattingEnabled = true;
            this.cboLoai.Items.AddRange(new object[] {
            "Tất cả",
            "Đã Đóng Tiền",
            "Chưa Đóng Tiền"});
            this.cboLoai.Location = new System.Drawing.Point(1098, 285);
            this.cboLoai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboLoai.Name = "cboLoai";
            this.cboLoai.Size = new System.Drawing.Size(121, 24);
            this.cboLoai.TabIndex = 29;
            this.cboLoai.Text = "Tất cả";
            this.cboLoai.SelectedIndexChanged += new System.EventHandler(this.cboLoai_SelectedIndexChanged);
            // 
            // btnTimKiemHD
            // 
            this.btnTimKiemHD.Location = new System.Drawing.Point(1017, 277);
            this.btnTimKiemHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTimKiemHD.Name = "btnTimKiemHD";
            this.btnTimKiemHD.Size = new System.Drawing.Size(75, 39);
            this.btnTimKiemHD.TabIndex = 28;
            this.btnTimKiemHD.Text = "Tìm Kiếm";
            this.btnTimKiemHD.UseVisualStyleBackColor = true;
            this.btnTimKiemHD.Click += new System.EventHandler(this.btnTimKiemHD_Click);
            // 
            // btnXacNhanDT
            // 
            this.btnXacNhanDT.Location = new System.Drawing.Point(926, 271);
            this.btnXacNhanDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXacNhanDT.Name = "btnXacNhanDT";
            this.btnXacNhanDT.Size = new System.Drawing.Size(85, 50);
            this.btnXacNhanDT.TabIndex = 27;
            this.btnXacNhanDT.Text = "Xác Nhận Đóng Tiền";
            this.btnXacNhanDT.UseVisualStyleBackColor = true;
            this.btnXacNhanDT.Click += new System.EventHandler(this.btnXacNhanDT_Click);
            // 
            // btnXoaHD
            // 
            this.btnXoaHD.Location = new System.Drawing.Point(824, 271);
            this.btnXoaHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaHD.Name = "btnXoaHD";
            this.btnXoaHD.Size = new System.Drawing.Size(96, 50);
            this.btnXoaHD.TabIndex = 26;
            this.btnXoaHD.Text = "Xóa Hóa Đơn";
            this.btnXoaHD.UseVisualStyleBackColor = true;
            this.btnXoaHD.Click += new System.EventHandler(this.btnXoaHD_Click);
            // 
            // btnTaoHD
            // 
            this.btnTaoHD.Location = new System.Drawing.Point(731, 271);
            this.btnTaoHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTaoHD.Name = "btnTaoHD";
            this.btnTaoHD.Size = new System.Drawing.Size(87, 50);
            this.btnTaoHD.TabIndex = 25;
            this.btnTaoHD.Text = "Tạo Hóa Đơn";
            this.btnTaoHD.UseVisualStyleBackColor = true;
            this.btnTaoHD.Click += new System.EventHandler(this.btnTaoHD_Click);
            // 
            // cboThangHD
            // 
            this.cboThangHD.FormattingEnabled = true;
            this.cboThangHD.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboThangHD.Location = new System.Drawing.Point(891, 121);
            this.cboThangHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboThangHD.Name = "cboThangHD";
            this.cboThangHD.Size = new System.Drawing.Size(193, 24);
            this.cboThangHD.TabIndex = 24;
            // 
            // txtTrangThai
            // 
            this.txtTrangThai.Location = new System.Drawing.Point(891, 204);
            this.txtTrangThai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTrangThai.Name = "txtTrangThai";
            this.txtTrangThai.ReadOnly = true;
            this.txtTrangThai.Size = new System.Drawing.Size(193, 22);
            this.txtTrangThai.TabIndex = 23;
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(891, 165);
            this.txtTongTien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.Size = new System.Drawing.Size(193, 22);
            this.txtTongTien.TabIndex = 22;
            // 
            // txtMaPhongHD
            // 
            this.txtMaPhongHD.Location = new System.Drawing.Point(891, 80);
            this.txtMaPhongHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPhongHD.Name = "txtMaPhongHD";
            this.txtMaPhongHD.Size = new System.Drawing.Size(193, 22);
            this.txtMaPhongHD.TabIndex = 21;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(745, 204);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 16);
            this.label24.TabIndex = 20;
            this.label24.Text = "Trạng Thái";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(744, 165);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 16);
            this.label25.TabIndex = 19;
            this.label25.Text = "Tổng Tiền";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(744, 123);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(46, 16);
            this.label26.TabIndex = 18;
            this.label26.Text = "Tháng";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(744, 80);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(68, 16);
            this.label27.TabIndex = 17;
            this.label27.Text = "Mã Phòng";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(744, 42);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 16);
            this.label28.TabIndex = 16;
            this.label28.Text = "Mã Hóa Đơn";
            // 
            // txtMaHD
            // 
            this.txtMaHD.Location = new System.Drawing.Point(891, 39);
            this.txtMaHD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(193, 22);
            this.txtMaHD.TabIndex = 15;
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(5, 21);
            this.dgvHoaDon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.ReadOnly = true;
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.RowTemplate.Height = 24;
            this.dgvHoaDon.Size = new System.Drawing.Size(711, 336);
            this.dgvHoaDon.TabIndex = 1;
            this.dgvHoaDon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHoaDon_CellClick);
            // 
            // grpTienNuoc
            // 
            this.grpTienNuoc.Controls.Add(this.btnCD);
            this.grpTienNuoc.Controls.Add(this.btnTimKiemTN);
            this.grpTienNuoc.Controls.Add(this.cboThangTN);
            this.grpTienNuoc.Controls.Add(this.btnXoaTN);
            this.grpTienNuoc.Controls.Add(this.btnThemTN);
            this.grpTienNuoc.Controls.Add(this.txtTienNuoc);
            this.grpTienNuoc.Controls.Add(this.txtNuocCuoiThang);
            this.grpTienNuoc.Controls.Add(this.txtNuocDauThang);
            this.grpTienNuoc.Controls.Add(this.label19);
            this.grpTienNuoc.Controls.Add(this.label20);
            this.grpTienNuoc.Controls.Add(this.label21);
            this.grpTienNuoc.Controls.Add(this.label22);
            this.grpTienNuoc.Controls.Add(this.label23);
            this.grpTienNuoc.Controls.Add(this.txtMaPhongTN);
            this.grpTienNuoc.Controls.Add(this.dgvTienNuoc);
            this.grpTienNuoc.Location = new System.Drawing.Point(685, 75);
            this.grpTienNuoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTienNuoc.Name = "grpTienNuoc";
            this.grpTienNuoc.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTienNuoc.Size = new System.Drawing.Size(696, 322);
            this.grpTienNuoc.TabIndex = 3;
            this.grpTienNuoc.TabStop = false;
            this.grpTienNuoc.Text = "Tiền Nước";
            // 
            // btnCD
            // 
            this.btnCD.Location = new System.Drawing.Point(507, 293);
            this.btnCD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCD.Name = "btnCD";
            this.btnCD.Size = new System.Drawing.Size(75, 23);
            this.btnCD.TabIndex = 29;
            this.btnCD.Text = "<>";
            this.btnCD.UseVisualStyleBackColor = true;
            this.btnCD.Click += new System.EventHandler(this.btnCD_Click);
            // 
            // btnTimKiemTN
            // 
            this.btnTimKiemTN.Location = new System.Drawing.Point(603, 257);
            this.btnTimKiemTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTimKiemTN.Name = "btnTimKiemTN";
            this.btnTimKiemTN.Size = new System.Drawing.Size(75, 23);
            this.btnTimKiemTN.TabIndex = 28;
            this.btnTimKiemTN.Text = "Tìm Kiếm";
            this.btnTimKiemTN.UseVisualStyleBackColor = true;
            this.btnTimKiemTN.Click += new System.EventHandler(this.btnTimKiemTN_Click);
            // 
            // cboThangTN
            // 
            this.cboThangTN.FormattingEnabled = true;
            this.cboThangTN.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboThangTN.Location = new System.Drawing.Point(579, 90);
            this.cboThangTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboThangTN.Name = "cboThangTN";
            this.cboThangTN.Size = new System.Drawing.Size(100, 24);
            this.cboThangTN.TabIndex = 27;
            // 
            // btnXoaTN
            // 
            this.btnXoaTN.Location = new System.Drawing.Point(507, 257);
            this.btnXoaTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaTN.Name = "btnXoaTN";
            this.btnXoaTN.Size = new System.Drawing.Size(75, 23);
            this.btnXoaTN.TabIndex = 26;
            this.btnXoaTN.Text = "Xóa";
            this.btnXoaTN.UseVisualStyleBackColor = true;
            this.btnXoaTN.Click += new System.EventHandler(this.btnXoaTN_Click);
            // 
            // btnThemTN
            // 
            this.btnThemTN.Location = new System.Drawing.Point(425, 257);
            this.btnThemTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThemTN.Name = "btnThemTN";
            this.btnThemTN.Size = new System.Drawing.Size(75, 23);
            this.btnThemTN.TabIndex = 25;
            this.btnThemTN.Text = "Thêm";
            this.btnThemTN.UseVisualStyleBackColor = true;
            this.btnThemTN.Click += new System.EventHandler(this.btnThemTN_Click);
            // 
            // txtTienNuoc
            // 
            this.txtTienNuoc.Location = new System.Drawing.Point(579, 214);
            this.txtTienNuoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTienNuoc.Name = "txtTienNuoc";
            this.txtTienNuoc.ReadOnly = true;
            this.txtTienNuoc.Size = new System.Drawing.Size(100, 22);
            this.txtTienNuoc.TabIndex = 24;
            // 
            // txtNuocCuoiThang
            // 
            this.txtNuocCuoiThang.Location = new System.Drawing.Point(579, 175);
            this.txtNuocCuoiThang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNuocCuoiThang.Name = "txtNuocCuoiThang";
            this.txtNuocCuoiThang.Size = new System.Drawing.Size(100, 22);
            this.txtNuocCuoiThang.TabIndex = 23;
            // 
            // txtNuocDauThang
            // 
            this.txtNuocDauThang.Location = new System.Drawing.Point(579, 133);
            this.txtNuocDauThang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNuocDauThang.Name = "txtNuocDauThang";
            this.txtNuocDauThang.Size = new System.Drawing.Size(100, 22);
            this.txtNuocDauThang.TabIndex = 22;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(433, 214);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 16);
            this.label19.TabIndex = 21;
            this.label19.Text = "Tiền nước";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(432, 175);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 16);
            this.label20.TabIndex = 20;
            this.label20.Text = "Số nước cuối tháng";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(432, 133);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 16);
            this.label21.TabIndex = 19;
            this.label21.Text = "Số  nước đầu tháng";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(432, 90);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 16);
            this.label22.TabIndex = 18;
            this.label22.Text = "Tháng";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(432, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 16);
            this.label23.TabIndex = 17;
            this.label23.Text = "Mã Phòng";
            // 
            // txtMaPhongTN
            // 
            this.txtMaPhongTN.Location = new System.Drawing.Point(579, 49);
            this.txtMaPhongTN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPhongTN.Name = "txtMaPhongTN";
            this.txtMaPhongTN.Size = new System.Drawing.Size(100, 22);
            this.txtMaPhongTN.TabIndex = 16;
            // 
            // dgvTienNuoc
            // 
            this.dgvTienNuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTienNuoc.Location = new System.Drawing.Point(5, 21);
            this.dgvTienNuoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvTienNuoc.Name = "dgvTienNuoc";
            this.dgvTienNuoc.ReadOnly = true;
            this.dgvTienNuoc.RowHeadersWidth = 51;
            this.dgvTienNuoc.RowTemplate.Height = 24;
            this.dgvTienNuoc.Size = new System.Drawing.Size(403, 295);
            this.dgvTienNuoc.TabIndex = 1;
            this.dgvTienNuoc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTienNuoc_CellClick);
            // 
            // grpTienDien
            // 
            this.grpTienDien.Controls.Add(this.btnTimKiemTD);
            this.grpTienDien.Controls.Add(this.cboThangTD);
            this.grpTienDien.Controls.Add(this.btnXoaTD);
            this.grpTienDien.Controls.Add(this.btnThemTD);
            this.grpTienDien.Controls.Add(this.txtTienDien);
            this.grpTienDien.Controls.Add(this.txtDienCuoiThang);
            this.grpTienDien.Controls.Add(this.txtDienDauThang);
            this.grpTienDien.Controls.Add(this.label18);
            this.grpTienDien.Controls.Add(this.label17);
            this.grpTienDien.Controls.Add(this.label15);
            this.grpTienDien.Controls.Add(this.label14);
            this.grpTienDien.Controls.Add(this.label13);
            this.grpTienDien.Controls.Add(this.txtMaPhongTD);
            this.grpTienDien.Controls.Add(this.dgvTienDien);
            this.grpTienDien.Location = new System.Drawing.Point(3, 75);
            this.grpTienDien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTienDien.Name = "grpTienDien";
            this.grpTienDien.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTienDien.Size = new System.Drawing.Size(676, 322);
            this.grpTienDien.TabIndex = 2;
            this.grpTienDien.TabStop = false;
            this.grpTienDien.Text = "Tiền Điện";
            this.grpTienDien.Enter += new System.EventHandler(this.grpTienDien_Enter);
            // 
            // btnTimKiemTD
            // 
            this.btnTimKiemTD.Location = new System.Drawing.Point(595, 271);
            this.btnTimKiemTD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTimKiemTD.Name = "btnTimKiemTD";
            this.btnTimKiemTD.Size = new System.Drawing.Size(75, 23);
            this.btnTimKiemTD.TabIndex = 15;
            this.btnTimKiemTD.Text = "Tìm Kiếm";
            this.btnTimKiemTD.UseVisualStyleBackColor = true;
            this.btnTimKiemTD.Click += new System.EventHandler(this.btnTimKiemTD_Click);
            // 
            // cboThangTD
            // 
            this.cboThangTD.FormattingEnabled = true;
            this.cboThangTD.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboThangTD.Location = new System.Drawing.Point(576, 87);
            this.cboThangTD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboThangTD.Name = "cboThangTD";
            this.cboThangTD.Size = new System.Drawing.Size(100, 24);
            this.cboThangTD.TabIndex = 14;
            // 
            // btnXoaTD
            // 
            this.btnXoaTD.Location = new System.Drawing.Point(504, 271);
            this.btnXoaTD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaTD.Name = "btnXoaTD";
            this.btnXoaTD.Size = new System.Drawing.Size(75, 23);
            this.btnXoaTD.TabIndex = 12;
            this.btnXoaTD.Text = "Xóa";
            this.btnXoaTD.UseVisualStyleBackColor = true;
            this.btnXoaTD.Click += new System.EventHandler(this.btnXoaTD_Click);
            // 
            // btnThemTD
            // 
            this.btnThemTD.Location = new System.Drawing.Point(423, 271);
            this.btnThemTD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThemTD.Name = "btnThemTD";
            this.btnThemTD.Size = new System.Drawing.Size(75, 23);
            this.btnThemTD.TabIndex = 11;
            this.btnThemTD.Text = "Thêm";
            this.btnThemTD.UseVisualStyleBackColor = true;
            this.btnThemTD.Click += new System.EventHandler(this.btnThemTD_Click);
            // 
            // txtTienDien
            // 
            this.txtTienDien.Location = new System.Drawing.Point(576, 210);
            this.txtTienDien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTienDien.Name = "txtTienDien";
            this.txtTienDien.ReadOnly = true;
            this.txtTienDien.Size = new System.Drawing.Size(100, 22);
            this.txtTienDien.TabIndex = 10;
            // 
            // txtDienCuoiThang
            // 
            this.txtDienCuoiThang.Location = new System.Drawing.Point(576, 172);
            this.txtDienCuoiThang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDienCuoiThang.Name = "txtDienCuoiThang";
            this.txtDienCuoiThang.Size = new System.Drawing.Size(100, 22);
            this.txtDienCuoiThang.TabIndex = 9;
            // 
            // txtDienDauThang
            // 
            this.txtDienDauThang.Location = new System.Drawing.Point(576, 130);
            this.txtDienDauThang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDienDauThang.Name = "txtDienDauThang";
            this.txtDienDauThang.Size = new System.Drawing.Size(100, 22);
            this.txtDienDauThang.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(431, 210);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 16);
            this.label18.TabIndex = 6;
            this.label18.Text = "Tiền điện";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(429, 172);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(117, 16);
            this.label17.TabIndex = 5;
            this.label17.Text = "Số điện cuối tháng";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(429, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 16);
            this.label15.TabIndex = 4;
            this.label15.Text = "Số  điện đầu tháng";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(429, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 16);
            this.label14.TabIndex = 3;
            this.label14.Text = "Tháng";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(429, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mã Phòng";
            // 
            // txtMaPhongTD
            // 
            this.txtMaPhongTD.Location = new System.Drawing.Point(576, 46);
            this.txtMaPhongTD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPhongTD.Name = "txtMaPhongTD";
            this.txtMaPhongTD.Size = new System.Drawing.Size(100, 22);
            this.txtMaPhongTD.TabIndex = 1;
            // 
            // dgvTienDien
            // 
            this.dgvTienDien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTienDien.Location = new System.Drawing.Point(7, 21);
            this.dgvTienDien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvTienDien.Name = "dgvTienDien";
            this.dgvTienDien.ReadOnly = true;
            this.dgvTienDien.RowHeadersWidth = 51;
            this.dgvTienDien.RowTemplate.Height = 24;
            this.dgvTienDien.Size = new System.Drawing.Size(403, 295);
            this.dgvTienDien.TabIndex = 0;
            this.dgvTienDien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTienDien_CellClick);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Yellow;
            this.label10.Location = new System.Drawing.Point(3, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1388, 69);
            this.label10.TabIndex = 1;
            this.label10.Text = "Quản lý điện nước";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbQLSV
            // 
            this.tbQLSV.Controls.Add(this.panel2);
            this.tbQLSV.Controls.Add(this.panel1);
            this.tbQLSV.Controls.Add(this.label1);
            this.tbQLSV.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tbQLSV.Location = new System.Drawing.Point(4, 25);
            this.tbQLSV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbQLSV.Name = "tbQLSV";
            this.tbQLSV.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbQLSV.Size = new System.Drawing.Size(1387, 769);
            this.tbQLSV.TabIndex = 0;
            this.tbQLSV.Text = "Quản lý sinh viên";
            this.tbQLSV.UseVisualStyleBackColor = true;
            this.tbQLSV.Click += new System.EventHandler(this.tbQLSV_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grpDanhSach);
            this.panel2.Location = new System.Drawing.Point(476, 75);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(905, 688);
            this.panel2.TabIndex = 2;
            // 
            // grpDanhSach
            // 
            this.grpDanhSach.Controls.Add(this.dgvSinhVien);
            this.grpDanhSach.ForeColor = System.Drawing.Color.Blue;
            this.grpDanhSach.Location = new System.Drawing.Point(3, 2);
            this.grpDanhSach.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDanhSach.Name = "grpDanhSach";
            this.grpDanhSach.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDanhSach.Size = new System.Drawing.Size(899, 686);
            this.grpDanhSach.TabIndex = 0;
            this.grpDanhSach.TabStop = false;
            this.grpDanhSach.Text = "Danh Sách";
            // 
            // dgvSinhVien
            // 
            this.dgvSinhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSinhVien.Location = new System.Drawing.Point(-3, 21);
            this.dgvSinhVien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvSinhVien.Name = "dgvSinhVien";
            this.dgvSinhVien.ReadOnly = true;
            this.dgvSinhVien.RowHeadersWidth = 51;
            this.dgvSinhVien.RowTemplate.Height = 24;
            this.dgvSinhVien.Size = new System.Drawing.Size(905, 665);
            this.dgvSinhVien.TabIndex = 0;
            this.dgvSinhVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSinhVien_CellClick);
            this.dgvSinhVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSinhVien_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grpTTSV);
            this.panel1.Location = new System.Drawing.Point(0, 75);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(469, 690);
            this.panel1.TabIndex = 1;
            // 
            // grpTTSV
            // 
            this.grpTTSV.Controls.Add(this.button1);
            this.grpTTSV.Controls.Add(this.btnDuyet);
            this.grpTTSV.Controls.Add(this.btnDSduyet);
            this.grpTTSV.Controls.Add(this.txtTaiKhoan);
            this.grpTTSV.Controls.Add(this.grbTimKiem);
            this.grpTTSV.Controls.Add(this.btnSua);
            this.grpTTSV.Controls.Add(this.btnXoa);
            this.grpTTSV.Controls.Add(this.txtSdt);
            this.grpTTSV.Controls.Add(this.txtMaToa);
            this.grpTTSV.Controls.Add(this.txtMaPhong);
            this.grpTTSV.Controls.Add(this.txtDiaChi);
            this.grpTTSV.Controls.Add(this.txtGT);
            this.grpTTSV.Controls.Add(this.dtpNgaySinh);
            this.grpTTSV.Controls.Add(this.txtCCCD);
            this.grpTTSV.Controls.Add(this.txtTen);
            this.grpTTSV.Controls.Add(this.txtMSV);
            this.grpTTSV.Controls.Add(this.label4);
            this.grpTTSV.Controls.Add(this.label11);
            this.grpTTSV.Controls.Add(this.label6);
            this.grpTTSV.Controls.Add(this.label7);
            this.grpTTSV.Controls.Add(this.label5);
            this.grpTTSV.Controls.Add(this.label16);
            this.grpTTSV.Controls.Add(this.label2);
            this.grpTTSV.Controls.Add(this.label3);
            this.grpTTSV.Controls.Add(this.label9);
            this.grpTTSV.Controls.Add(this.label12);
            this.grpTTSV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpTTSV.ForeColor = System.Drawing.Color.Blue;
            this.grpTTSV.Location = new System.Drawing.Point(0, 0);
            this.grpTTSV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTTSV.Name = "grpTTSV";
            this.grpTTSV.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpTTSV.Size = new System.Drawing.Size(469, 690);
            this.grpTTSV.TabIndex = 0;
            this.grpTTSV.TabStop = false;
            this.grpTTSV.Text = "Thông Tin Chi Tiết";
            // 
            // btnDuyet
            // 
            this.btnDuyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDuyet.Location = new System.Drawing.Point(175, 520);
            this.btnDuyet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDuyet.Name = "btnDuyet";
            this.btnDuyet.Size = new System.Drawing.Size(96, 52);
            this.btnDuyet.TabIndex = 156;
            this.btnDuyet.Text = "Duyệt";
            this.btnDuyet.UseVisualStyleBackColor = true;
            this.btnDuyet.Click += new System.EventHandler(this.btnDuyet_Click);
            // 
            // btnDSduyet
            // 
            this.btnDSduyet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDSduyet.Location = new System.Drawing.Point(8, 520);
            this.btnDSduyet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDSduyet.Name = "btnDSduyet";
            this.btnDSduyet.Size = new System.Drawing.Size(155, 52);
            this.btnDSduyet.TabIndex = 155;
            this.btnDSduyet.Text = "Danh sách duyệt";
            this.btnDSduyet.UseVisualStyleBackColor = true;
            this.btnDSduyet.Click += new System.EventHandler(this.btnDSduyet_Click);
            // 
            // txtTaiKhoan
            // 
            this.txtTaiKhoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaiKhoan.Location = new System.Drawing.Point(276, 455);
            this.txtTaiKhoan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTaiKhoan.Name = "txtTaiKhoan";
            this.txtTaiKhoan.Size = new System.Drawing.Size(155, 43);
            this.txtTaiKhoan.TabIndex = 154;
            this.txtTaiKhoan.Text = "Xem Tài Khoản";
            this.txtTaiKhoan.UseVisualStyleBackColor = true;
            this.txtTaiKhoan.Click += new System.EventHandler(this.txtTaiKhoan_Click);
            // 
            // grbTimKiem
            // 
            this.grbTimKiem.Controls.Add(this.cboLoaiTimKiem);
            this.grbTimKiem.Controls.Add(this.txtTimKiem);
            this.grbTimKiem.Controls.Add(this.label8);
            this.grbTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.grbTimKiem.Location = new System.Drawing.Point(4, 596);
            this.grbTimKiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbTimKiem.Name = "grbTimKiem";
            this.grbTimKiem.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbTimKiem.Size = new System.Drawing.Size(463, 102);
            this.grbTimKiem.TabIndex = 153;
            this.grbTimKiem.TabStop = false;
            this.grbTimKiem.Text = "Tìm Kiếm";
            // 
            // cboLoaiTimKiem
            // 
            this.cboLoaiTimKiem.FormattingEnabled = true;
            this.cboLoaiTimKiem.Items.AddRange(new object[] {
            "Tên",
            "Mã SV",
            "Phòng"});
            this.cboLoaiTimKiem.Location = new System.Drawing.Point(331, 34);
            this.cboLoaiTimKiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboLoaiTimKiem.Name = "cboLoaiTimKiem";
            this.cboLoaiTimKiem.Size = new System.Drawing.Size(76, 24);
            this.cboLoaiTimKiem.TabIndex = 151;
            this.cboLoaiTimKiem.SelectedIndexChanged += new System.EventHandler(this.cboLoaiTimKiem_SelectedIndexChanged);
            // 
            // txtTimKiem
            // 
            this.txtTimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiem.Location = new System.Drawing.Point(133, 31);
            this.txtTimKiem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTimKiem.Name = "txtTimKiem";
            this.txtTimKiem.Size = new System.Drawing.Size(192, 28);
            this.txtTimKiem.TabIndex = 150;
            this.txtTimKiem.TextChanged += new System.EventHandler(this.txtTimKiem_TextChanged);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(5, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 30);
            this.label8.TabIndex = 142;
            this.label8.Text = "Thông Tin";
            // 
            // btnSua
            // 
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Location = new System.Drawing.Point(139, 455);
            this.btnSua.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(115, 43);
            this.btnSua.TabIndex = 152;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.Location = new System.Drawing.Point(13, 455);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(115, 43);
            this.btnXoa.TabIndex = 151;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // txtSdt
            // 
            this.txtSdt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSdt.Location = new System.Drawing.Point(175, 325);
            this.txtSdt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSdt.Name = "txtSdt";
            this.txtSdt.Size = new System.Drawing.Size(192, 28);
            this.txtSdt.TabIndex = 150;
            // 
            // txtMaToa
            // 
            this.txtMaToa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaToa.Location = new System.Drawing.Point(175, 415);
            this.txtMaToa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaToa.Name = "txtMaToa";
            this.txtMaToa.Size = new System.Drawing.Size(192, 28);
            this.txtMaToa.TabIndex = 149;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaPhong.Location = new System.Drawing.Point(175, 372);
            this.txtMaPhong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(192, 28);
            this.txtMaPhong.TabIndex = 148;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi.Location = new System.Drawing.Point(175, 278);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(192, 28);
            this.txtDiaChi.TabIndex = 147;
            // 
            // txtGT
            // 
            this.txtGT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGT.Location = new System.Drawing.Point(175, 183);
            this.txtGT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGT.Name = "txtGT";
            this.txtGT.Size = new System.Drawing.Size(192, 28);
            this.txtGT.TabIndex = 146;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(177, 130);
            this.dtpNgaySinh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(176, 28);
            this.dtpNgaySinh.TabIndex = 145;
            // 
            // txtCCCD
            // 
            this.txtCCCD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCCCD.Location = new System.Drawing.Point(175, 230);
            this.txtCCCD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCCCD.Name = "txtCCCD";
            this.txtCCCD.Size = new System.Drawing.Size(192, 28);
            this.txtCCCD.TabIndex = 144;
            // 
            // txtTen
            // 
            this.txtTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTen.Location = new System.Drawing.Point(179, 84);
            this.txtTen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(188, 28);
            this.txtTen.TabIndex = 143;
            // 
            // txtMSV
            // 
            this.txtMSV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSV.Location = new System.Drawing.Point(179, 34);
            this.txtMSV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMSV.Name = "txtMSV";
            this.txtMSV.Size = new System.Drawing.Size(188, 28);
            this.txtMSV.TabIndex = 142;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 414);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 30);
            this.label4.TabIndex = 141;
            this.label4.Text = "Mã Tòa";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(3, 370);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 36);
            this.label11.TabIndex = 140;
            this.label11.Text = "Mã Phòng";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(3, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 31);
            this.label6.TabIndex = 138;
            this.label6.Text = "SĐT";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 30);
            this.label7.TabIndex = 139;
            this.label7.Text = "Địa chỉ";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(11, 443);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 30);
            this.label5.TabIndex = 137;
            this.label5.Text = " ";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(3, 230);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 28);
            this.label16.TabIndex = 135;
            this.label16.Text = "CCCD";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 33);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 25);
            this.label2.TabIndex = 131;
            this.label2.Text = "Mã Sinh Viên";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 84);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 28);
            this.label3.TabIndex = 132;
            this.label3.Text = "Họ Tên";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 181);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 28);
            this.label9.TabIndex = 133;
            this.label9.Text = "Giới Tính";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(3, 129);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(171, 30);
            this.label12.TabIndex = 134;
            this.label12.Text = "Ngày Sinh";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1379, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thông Tin Sinh Viên";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabKyLuat
            // 
            this.tabKyLuat.Controls.Add(this.tbQLSV);
            this.tabKyLuat.Controls.Add(this.tabQLDN);
            this.tabKyLuat.Controls.Add(this.tbHDTP);
            this.tabKyLuat.Controls.Add(this.tbThongTin);
            this.tabKyLuat.Controls.Add(this.tpTTTaiKhoan);
            this.tabKyLuat.Controls.Add(this.tabPage1);
            this.tabKyLuat.Location = new System.Drawing.Point(3, 2);
            this.tabKyLuat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabKyLuat.Name = "tabKyLuat";
            this.tabKyLuat.SelectedIndex = 0;
            this.tabKyLuat.Size = new System.Drawing.Size(1395, 798);
            this.tabKyLuat.TabIndex = 0;
            // 
            // tpTTTaiKhoan
            // 
            this.tpTTTaiKhoan.Controls.Add(this.groupBox7);
            this.tpTTTaiKhoan.Controls.Add(this.groupBox6);
            this.tpTTTaiKhoan.Controls.Add(this.groupBox5);
            this.tpTTTaiKhoan.Controls.Add(this.label43);
            this.tpTTTaiKhoan.Location = new System.Drawing.Point(4, 25);
            this.tpTTTaiKhoan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTTTaiKhoan.Name = "tpTTTaiKhoan";
            this.tpTTTaiKhoan.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTTTaiKhoan.Size = new System.Drawing.Size(1387, 769);
            this.tpTTTaiKhoan.TabIndex = 4;
            this.tpTTTaiKhoan.Text = "Quản lý phòng";
            this.tpTTTaiKhoan.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(277, 520);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 52);
            this.button1.TabIndex = 157;
            this.button1.Text = "Danh sách gia hạn";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.btnSuaTTQL);
            this.tabPage1.Controls.Add(this.btnDoiMatKhau);
            this.tabPage1.Controls.Add(this.txtChucVu);
            this.tabPage1.Controls.Add(this.txtToaQL);
            this.tabPage1.Controls.Add(this.txtTenQL);
            this.tabPage1.Controls.Add(this.txtMaQL);
            this.tabPage1.Controls.Add(this.label35);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1387, 769);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Thôn tin tài khoản";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnSuaTTQL
            // 
            this.btnSuaTTQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaTTQL.Location = new System.Drawing.Point(731, 556);
            this.btnSuaTTQL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSuaTTQL.Name = "btnSuaTTQL";
            this.btnSuaTTQL.Size = new System.Drawing.Size(163, 57);
            this.btnSuaTTQL.TabIndex = 188;
            this.btnSuaTTQL.Text = "Sửa Thông TIn ";
            this.btnSuaTTQL.UseVisualStyleBackColor = true;
            // 
            // btnDoiMatKhau
            // 
            this.btnDoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoiMatKhau.Location = new System.Drawing.Point(497, 556);
            this.btnDoiMatKhau.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDoiMatKhau.Name = "btnDoiMatKhau";
            this.btnDoiMatKhau.Size = new System.Drawing.Size(163, 57);
            this.btnDoiMatKhau.TabIndex = 187;
            this.btnDoiMatKhau.Text = "Đổi mật khẩu";
            this.btnDoiMatKhau.UseVisualStyleBackColor = true;
            // 
            // txtChucVu
            // 
            this.txtChucVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChucVu.Location = new System.Drawing.Point(652, 449);
            this.txtChucVu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.ReadOnly = true;
            this.txtChucVu.Size = new System.Drawing.Size(188, 28);
            this.txtChucVu.TabIndex = 186;
            // 
            // txtToaQL
            // 
            this.txtToaQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtToaQL.Location = new System.Drawing.Point(652, 377);
            this.txtToaQL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtToaQL.Name = "txtToaQL";
            this.txtToaQL.Size = new System.Drawing.Size(188, 28);
            this.txtToaQL.TabIndex = 184;
            // 
            // txtTenQL
            // 
            this.txtTenQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenQL.Location = new System.Drawing.Point(652, 299);
            this.txtTenQL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenQL.Name = "txtTenQL";
            this.txtTenQL.Size = new System.Drawing.Size(188, 28);
            this.txtTenQL.TabIndex = 182;
            // 
            // txtMaQL
            // 
            this.txtMaQL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaQL.Location = new System.Drawing.Point(652, 229);
            this.txtMaQL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaQL.Name = "txtMaQL";
            this.txtMaQL.ReadOnly = true;
            this.txtMaQL.Size = new System.Drawing.Size(188, 28);
            this.txtMaQL.TabIndex = 180;
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(492, 448);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(155, 31);
            this.label35.TabIndex = 185;
            this.label35.Text = "Chức Vụ";
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(492, 374);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(155, 31);
            this.label34.TabIndex = 183;
            this.label34.Text = "Tòa Quản Lý";
            // 
            // label33
            // 
            this.label33.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(492, 299);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(155, 31);
            this.label33.TabIndex = 181;
            this.label33.Text = "Họ Tên";
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(492, 225);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(155, 31);
            this.label32.TabIndex = 179;
            this.label32.Text = "Mã Quản Lý";
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Yellow;
            this.label31.Location = new System.Drawing.Point(-7, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(1388, 69);
            this.label31.TabIndex = 189;
            this.label31.Text = "Thông tin tài khoản";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Yellow;
            this.label43.Location = new System.Drawing.Point(5, 2);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(1388, 69);
            this.label43.TabIndex = 190;
            this.label43.Text = "Quản Lý Phòng";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dgvPhong);
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(492, 73);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(899, 686);
            this.groupBox5.TabIndex = 191;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Phòng";
            // 
            // dgvPhong
            // 
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(-3, 21);
            this.dgvPhong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.ReadOnly = true;
            this.dgvPhong.RowHeadersWidth = 51;
            this.dgvPhong.RowTemplate.Height = 24;
            this.dgvPhong.Size = new System.Drawing.Size(905, 665);
            this.dgvPhong.TabIndex = 0;
            this.dgvPhong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhong_CellClick);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnThemP);
            this.groupBox6.Controls.Add(this.btnXoaP);
            this.groupBox6.Controls.Add(this.txtSoNguoiO);
            this.groupBox6.Controls.Add(this.label47);
            this.groupBox6.Controls.Add(this.txtMaToap);
            this.groupBox6.Controls.Add(this.label46);
            this.groupBox6.Controls.Add(this.txtLoaiPhong);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Controls.Add(this.txtMaPhongp);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Location = new System.Drawing.Point(4, 75);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(482, 684);
            this.groupBox6.TabIndex = 192;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thông tin";
            // 
            // txtMaPhongp
            // 
            this.txtMaPhongp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaPhongp.Location = new System.Drawing.Point(217, 78);
            this.txtMaPhongp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPhongp.Name = "txtMaPhongp";
            this.txtMaPhongp.Size = new System.Drawing.Size(188, 28);
            this.txtMaPhongp.TabIndex = 144;
            // 
            // label44
            // 
            this.label44.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(10, 76);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(155, 29);
            this.label44.TabIndex = 143;
            this.label44.Text = "Mã Phòng";
            // 
            // txtLoaiPhong
            // 
            this.txtLoaiPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoaiPhong.Location = new System.Drawing.Point(217, 143);
            this.txtLoaiPhong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLoaiPhong.Name = "txtLoaiPhong";
            this.txtLoaiPhong.Size = new System.Drawing.Size(188, 28);
            this.txtLoaiPhong.TabIndex = 146;
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(10, 141);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(169, 29);
            this.label45.TabIndex = 145;
            this.label45.Text = "Loại phòng";
            // 
            // txtMaToap
            // 
            this.txtMaToap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaToap.Location = new System.Drawing.Point(217, 213);
            this.txtMaToap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaToap.Name = "txtMaToap";
            this.txtMaToap.Size = new System.Drawing.Size(188, 28);
            this.txtMaToap.TabIndex = 148;
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(10, 211);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(155, 25);
            this.label46.TabIndex = 147;
            this.label46.Text = "Mã Tòa";
            // 
            // txtSoNguoiO
            // 
            this.txtSoNguoiO.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNguoiO.Location = new System.Drawing.Point(217, 283);
            this.txtSoNguoiO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSoNguoiO.Name = "txtSoNguoiO";
            this.txtSoNguoiO.Size = new System.Drawing.Size(188, 28);
            this.txtSoNguoiO.TabIndex = 150;
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Black;
            this.label47.Location = new System.Drawing.Point(10, 283);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(183, 28);
            this.label47.TabIndex = 149;
            this.label47.Text = "Số Người Đang Ở";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtTKPhong);
            this.groupBox7.Controls.Add(this.Max);
            this.groupBox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox7.Location = new System.Drawing.Point(3, 555);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(463, 209);
            this.groupBox7.TabIndex = 154;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tìm Kiếm";
            // 
            // txtTKPhong
            // 
            this.txtTKPhong.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTKPhong.Location = new System.Drawing.Point(136, 32);
            this.txtTKPhong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTKPhong.Name = "txtTKPhong";
            this.txtTKPhong.Size = new System.Drawing.Size(192, 28);
            this.txtTKPhong.TabIndex = 150;
            this.txtTKPhong.TextChanged += new System.EventHandler(this.txtTKPhong_TextChanged);
            // 
            // Max
            // 
            this.Max.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Max.ForeColor = System.Drawing.Color.Black;
            this.Max.Location = new System.Drawing.Point(5, 30);
            this.Max.Name = "Max";
            this.Max.Size = new System.Drawing.Size(125, 30);
            this.Max.TabIndex = 142;
            this.Max.Text = "Mã Phòng";
            // 
            // btnXoaP
            // 
            this.btnXoaP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaP.Location = new System.Drawing.Point(50, 369);
            this.btnXoaP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXoaP.Name = "btnXoaP";
            this.btnXoaP.Size = new System.Drawing.Size(115, 43);
            this.btnXoaP.TabIndex = 152;
            this.btnXoaP.Text = "Xóa";
            this.btnXoaP.UseVisualStyleBackColor = true;
            this.btnXoaP.Click += new System.EventHandler(this.btnXoaP_Click);
            // 
            // btnThemP
            // 
            this.btnThemP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemP.Location = new System.Drawing.Point(217, 369);
            this.btnThemP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThemP.Name = "btnThemP";
            this.btnThemP.Size = new System.Drawing.Size(115, 43);
            this.btnThemP.TabIndex = 153;
            this.btnThemP.Text = "Thêm";
            this.btnThemP.UseVisualStyleBackColor = true;
            this.btnThemP.Click += new System.EventHandler(this.btnThemP_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtTienConLai);
            this.groupBox8.Controls.Add(this.label50);
            this.groupBox8.Controls.Add(this.txtTienDaThu);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.txtTongTDN);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.cboThangTT);
            this.groupBox8.Controls.Add(this.D);
            this.groupBox8.Location = new System.Drawing.Point(1110, 21);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(255, 216);
            this.groupBox8.TabIndex = 30;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Tồng Tiền";
            // 
            // D
            // 
            this.D.AutoSize = true;
            this.D.Location = new System.Drawing.Point(6, 24);
            this.D.Name = "D";
            this.D.Size = new System.Drawing.Size(46, 16);
            this.D.TabIndex = 17;
            this.D.Text = "Tháng";
            // 
            // cboThangTT
            // 
            this.cboThangTT.FormattingEnabled = true;
            this.cboThangTT.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cboThangTT.Location = new System.Drawing.Point(121, 20);
            this.cboThangTT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboThangTT.Name = "cboThangTT";
            this.cboThangTT.Size = new System.Drawing.Size(108, 24);
            this.cboThangTT.TabIndex = 25;
            this.cboThangTT.SelectedIndexChanged += new System.EventHandler(this.cboThangTT_SelectedIndexChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 59);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(69, 16);
            this.label48.TabIndex = 26;
            this.label48.Text = "Tông Tiền";
            // 
            // txtTongTDN
            // 
            this.txtTongTDN.Location = new System.Drawing.Point(121, 59);
            this.txtTongTDN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTongTDN.Name = "txtTongTDN";
            this.txtTongTDN.Size = new System.Drawing.Size(108, 22);
            this.txtTongTDN.TabIndex = 31;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 102);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(87, 16);
            this.label49.TabIndex = 32;
            this.label49.Text = "Tiền đã đóng";
            // 
            // txtTienDaThu
            // 
            this.txtTienDaThu.Location = new System.Drawing.Point(121, 96);
            this.txtTienDaThu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTienDaThu.Name = "txtTienDaThu";
            this.txtTienDaThu.Size = new System.Drawing.Size(108, 22);
            this.txtTienDaThu.TabIndex = 33;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 144);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(76, 16);
            this.label50.TabIndex = 34;
            this.label50.Text = "Tiền còn lại";
            // 
            // txtTienConLai
            // 
            this.txtTienConLai.Location = new System.Drawing.Point(121, 138);
            this.txtTienConLai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTienConLai.Name = "txtTienConLai";
            this.txtTienConLai.Size = new System.Drawing.Size(108, 22);
            this.txtTienConLai.TabIndex = 35;
            // 
            // fQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1400, 802);
            this.Controls.Add(this.tabKyLuat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "fQuanLy";
            this.Text = "Quản Lý";
            this.Load += new System.EventHandler(this.fQuanLy_Load);
            this.tbThongTin.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKyLuat)).EndInit();
            this.tbHDTP.ResumeLayout(false);
            this.grpHopDong.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            this.tabQLDN.ResumeLayout(false);
            this.grpHoaDon.ResumeLayout(false);
            this.grpHoaDon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.grpTienNuoc.ResumeLayout(false);
            this.grpTienNuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienNuoc)).EndInit();
            this.grpTienDien.ResumeLayout(false);
            this.grpTienDien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTienDien)).EndInit();
            this.tbQLSV.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.grpDanhSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSinhVien)).EndInit();
            this.panel1.ResumeLayout(false);
            this.grpTTSV.ResumeLayout(false);
            this.grpTTSV.PerformLayout();
            this.grbTimKiem.ResumeLayout(false);
            this.grbTimKiem.PerformLayout();
            this.tabKyLuat.ResumeLayout(false);
            this.tpTTTaiKhoan.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TabPage tbThongTin;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnXoaKL;
        private System.Windows.Forms.Button btnThemKL;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.DateTimePicker dtpNgayViPham;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtLoiViPham;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtMaKyLuat;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtMaSVKL;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvKyLuat;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TabPage tbHDTP;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox grpHopDong;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboLoaiTKHD;
        private System.Windows.Forms.TextBox txtTimKiemHD;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView dgvHopDong;
        private System.Windows.Forms.TabPage tabQLDN;
        private System.Windows.Forms.GroupBox grpHoaDon;
        private System.Windows.Forms.ComboBox cboLoai;
        private System.Windows.Forms.Button btnTimKiemHD;
        private System.Windows.Forms.Button btnXacNhanDT;
        private System.Windows.Forms.Button btnXoaHD;
        private System.Windows.Forms.Button btnTaoHD;
        private System.Windows.Forms.ComboBox cboThangHD;
        private System.Windows.Forms.TextBox txtTrangThai;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.TextBox txtMaPhongHD;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtMaHD;
        private System.Windows.Forms.DataGridView dgvHoaDon;
        private System.Windows.Forms.GroupBox grpTienNuoc;
        private System.Windows.Forms.Button btnCD;
        private System.Windows.Forms.Button btnTimKiemTN;
        private System.Windows.Forms.ComboBox cboThangTN;
        private System.Windows.Forms.Button btnXoaTN;
        private System.Windows.Forms.Button btnThemTN;
        private System.Windows.Forms.TextBox txtTienNuoc;
        private System.Windows.Forms.TextBox txtNuocCuoiThang;
        private System.Windows.Forms.TextBox txtNuocDauThang;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtMaPhongTN;
        private System.Windows.Forms.DataGridView dgvTienNuoc;
        private System.Windows.Forms.GroupBox grpTienDien;
        private System.Windows.Forms.Button btnTimKiemTD;
        private System.Windows.Forms.ComboBox cboThangTD;
        private System.Windows.Forms.Button btnXoaTD;
        private System.Windows.Forms.Button btnThemTD;
        private System.Windows.Forms.TextBox txtTienDien;
        private System.Windows.Forms.TextBox txtDienCuoiThang;
        private System.Windows.Forms.TextBox txtDienDauThang;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMaPhongTD;
        private System.Windows.Forms.DataGridView dgvTienDien;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tbQLSV;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox grpDanhSach;
        private System.Windows.Forms.DataGridView dgvSinhVien;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grpTTSV;
        private System.Windows.Forms.Button txtTaiKhoan;
        private System.Windows.Forms.GroupBox grbTimKiem;
        private System.Windows.Forms.ComboBox cboLoaiTimKiem;
        private System.Windows.Forms.TextBox txtTimKiem;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.TextBox txtSdt;
        private System.Windows.Forms.TextBox txtMaToa;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtGT;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtCCCD;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtMSV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabKyLuat;
        private System.Windows.Forms.TabPage tpTTTaiKhoan;
        public System.Windows.Forms.TextBox txtMaToaKL;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtmaKL;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button btnDSduyet;
        private System.Windows.Forms.Button btnDuyet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtSoNguoiO;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtMaToap;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtLoaiPhong;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtMaPhongp;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnSuaTTQL;
        private System.Windows.Forms.Button btnDoiMatKhau;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.TextBox txtToaQL;
        private System.Windows.Forms.TextBox txtTenQL;
        private System.Windows.Forms.TextBox txtMaQL;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtTKPhong;
        private System.Windows.Forms.Label Max;
        private System.Windows.Forms.Button btnThemP;
        private System.Windows.Forms.Button btnXoaP;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtTongTDN;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox cboThangTT;
        private System.Windows.Forms.Label D;
        private System.Windows.Forms.TextBox txtTienDaThu;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtTienConLai;
        private System.Windows.Forms.Label label50;
    }
}