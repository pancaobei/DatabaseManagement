﻿namespace QLSV.Views
{
    partial class fSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.dtgvDien = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.cbThang = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnXemDien = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtTen2 = new System.Windows.Forms.TextBox();
            this.dtgvNuoc = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.cbThang2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMaPhong2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnXem2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.cbThang3 = new System.Windows.Forms.ComboBox();
            this.dtgvHoaDon = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAnh = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAnh = new System.Windows.Forms.TextBox();
            this.PB = new System.Windows.Forms.PictureBox();
            this.txtGioiTinh = new System.Windows.Forms.TextBox();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnDoiMatKhau = new System.Windows.Forms.Button();
            this.txtPhong = new System.Windows.Forms.TextBox();
            this.txtMaToa = new System.Windows.Forms.TextBox();
            this.txtMaSv = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSua = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCCCD = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.dtpkNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.tabpage5 = new System.Windows.Forms.TabPage();
            this.btnGiaHan = new System.Windows.Forms.Button();
            this.tbSoTien = new System.Windows.Forms.TextBox();
            this.tbSoKy = new System.Windows.Forms.TextBox();
            this.tbMssv = new System.Windows.Forms.TextBox();
            this.tbMaPhong = new System.Windows.Forms.TextBox();
            this.dtpkTraPhong = new System.Windows.Forms.DateTimePicker();
            this.dtpkNhanPhong = new System.Windows.Forms.DateTimePicker();
            this.lable32 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lable31 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dtgvXemThanhVien = new System.Windows.Forms.DataGridView();
            this.lbxemthanhvien = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ODL = new System.Windows.Forms.OpenFileDialog();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDien)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvNuoc)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHoaDon)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB)).BeginInit();
            this.tabpage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvXemThanhVien)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabpage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 471);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 445);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tiền Điện";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtTen);
            this.panel1.Controls.Add(this.dtgvDien);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cbThang);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtMaPhong);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnXemDien);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(756, 433);
            this.panel1.TabIndex = 8;
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(102, 12);
            this.txtTen.Name = "txtTen";
            this.txtTen.ReadOnly = true;
            this.txtTen.Size = new System.Drawing.Size(296, 20);
            this.txtTen.TabIndex = 4;
            // 
            // dtgvDien
            // 
            this.dtgvDien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvDien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDien.Location = new System.Drawing.Point(3, 77);
            this.dtgvDien.Name = "dtgvDien";
            this.dtgvDien.RowHeadersWidth = 51;
            this.dtgvDien.Size = new System.Drawing.Size(750, 353);
            this.dtgvDien.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(420, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tháng:";
            // 
            // cbThang
            // 
            this.cbThang.FormattingEnabled = true;
            this.cbThang.Location = new System.Drawing.Point(467, 39);
            this.cbThang.Name = "cbThang";
            this.cbThang.Size = new System.Drawing.Size(150, 21);
            this.cbThang.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Mã Phòng:";
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(102, 40);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.ReadOnly = true;
            this.txtMaPhong.Size = new System.Drawing.Size(296, 20);
            this.txtMaPhong.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tên Sinh Viên:";
            // 
            // btnXemDien
            // 
            this.btnXemDien.Location = new System.Drawing.Point(630, 8);
            this.btnXemDien.Name = "btnXemDien";
            this.btnXemDien.Size = new System.Drawing.Size(123, 52);
            this.btnXemDien.TabIndex = 3;
            this.btnXemDien.Text = "Xem";
            this.btnXemDien.UseVisualStyleBackColor = true;
            this.btnXemDien.Click += new System.EventHandler(this.btnXemDien_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 445);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tiền Nước";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtTen2);
            this.panel2.Controls.Add(this.dtgvNuoc);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.cbThang2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtMaPhong2);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.btnXem2);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(756, 433);
            this.panel2.TabIndex = 9;
            // 
            // txtTen2
            // 
            this.txtTen2.Location = new System.Drawing.Point(102, 12);
            this.txtTen2.Name = "txtTen2";
            this.txtTen2.ReadOnly = true;
            this.txtTen2.Size = new System.Drawing.Size(296, 20);
            this.txtTen2.TabIndex = 4;
            // 
            // dtgvNuoc
            // 
            this.dtgvNuoc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvNuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvNuoc.Location = new System.Drawing.Point(3, 77);
            this.dtgvNuoc.Name = "dtgvNuoc";
            this.dtgvNuoc.RowHeadersWidth = 51;
            this.dtgvNuoc.Size = new System.Drawing.Size(750, 353);
            this.dtgvNuoc.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(420, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tháng:";
            // 
            // cbThang2
            // 
            this.cbThang2.FormattingEnabled = true;
            this.cbThang2.Location = new System.Drawing.Point(467, 39);
            this.cbThang2.Name = "cbThang2";
            this.cbThang2.Size = new System.Drawing.Size(150, 21);
            this.cbThang2.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Mã Phòng:";
            // 
            // txtMaPhong2
            // 
            this.txtMaPhong2.Location = new System.Drawing.Point(102, 40);
            this.txtMaPhong2.Name = "txtMaPhong2";
            this.txtMaPhong2.ReadOnly = true;
            this.txtMaPhong2.Size = new System.Drawing.Size(296, 20);
            this.txtMaPhong2.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tên Sinh Viên:";
            // 
            // btnXem2
            // 
            this.btnXem2.Location = new System.Drawing.Point(630, 8);
            this.btnXem2.Name = "btnXem2";
            this.btnXem2.Size = new System.Drawing.Size(123, 52);
            this.btnXem2.TabIndex = 3;
            this.btnXem2.Text = "Xem";
            this.btnXem2.UseVisualStyleBackColor = true;
            this.btnXem2.Click += new System.EventHandler(this.btnXem2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.cbThang3);
            this.tabPage3.Controls.Add(this.dtgvHoaDon);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 445);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Hóa Đơn Điện Nước";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 97);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Tháng: ";
            // 
            // cbThang3
            // 
            this.cbThang3.FormattingEnabled = true;
            this.cbThang3.Location = new System.Drawing.Point(50, 94);
            this.cbThang3.Name = "cbThang3";
            this.cbThang3.Size = new System.Drawing.Size(121, 21);
            this.cbThang3.TabIndex = 3;
            this.cbThang3.SelectedIndexChanged += new System.EventHandler(this.cbthang3_SelectedIndexChanged);
            // 
            // dtgvHoaDon
            // 
            this.dtgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvHoaDon.Location = new System.Drawing.Point(3, 120);
            this.dtgvHoaDon.Name = "dtgvHoaDon";
            this.dtgvHoaDon.RowHeadersWidth = 51;
            this.dtgvHoaDon.Size = new System.Drawing.Size(759, 319);
            this.dtgvHoaDon.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Yellow;
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(762, 66);
            this.label17.TabIndex = 1;
            this.label17.Text = "Hóa Đơn Điện Nước";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(768, 445);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Sinh Viên";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btnAnh);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txtAnh);
            this.panel3.Controls.Add(this.PB);
            this.panel3.Controls.Add(this.txtGioiTinh);
            this.panel3.Controls.Add(this.btnDangXuat);
            this.panel3.Controls.Add(this.btnDoiMatKhau);
            this.panel3.Controls.Add(this.txtPhong);
            this.panel3.Controls.Add(this.txtMaToa);
            this.panel3.Controls.Add(this.txtMaSv);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.btnSua);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtHoTen);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.txtCCCD);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.txtSDT);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.txtDiaChi);
            this.panel3.Controls.Add(this.dtpkNgaySinh);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Location = new System.Drawing.Point(2, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(765, 436);
            this.panel3.TabIndex = 42;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(178, 248);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 46);
            this.button1.TabIndex = 49;
            this.button1.Text = "Xem Kỷ Luật";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAnh
            // 
            this.btnAnh.Location = new System.Drawing.Point(651, 208);
            this.btnAnh.Name = "btnAnh";
            this.btnAnh.Size = new System.Drawing.Size(75, 23);
            this.btnAnh.TabIndex = 48;
            this.btnAnh.Text = "Chọn ảnh";
            this.btnAnh.UseVisualStyleBackColor = true;
            this.btnAnh.Click += new System.EventHandler(this.btnAnh_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(430, 208);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 20);
            this.label10.TabIndex = 47;
            this.label10.Text = "Đổi ảnh: ";
            // 
            // txtAnh
            // 
            this.txtAnh.Location = new System.Drawing.Point(539, 208);
            this.txtAnh.Name = "txtAnh";
            this.txtAnh.Size = new System.Drawing.Size(100, 20);
            this.txtAnh.TabIndex = 46;
            // 
            // PB
            // 
            this.PB.Location = new System.Drawing.Point(539, 233);
            this.PB.Margin = new System.Windows.Forms.Padding(2);
            this.PB.Name = "PB";
            this.PB.Size = new System.Drawing.Size(187, 119);
            this.PB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PB.TabIndex = 45;
            this.PB.TabStop = false;
            // 
            // txtGioiTinh
            // 
            this.txtGioiTinh.Location = new System.Drawing.Point(151, 162);
            this.txtGioiTinh.Margin = new System.Windows.Forms.Padding(2);
            this.txtGioiTinh.Name = "txtGioiTinh";
            this.txtGioiTinh.ReadOnly = true;
            this.txtGioiTinh.Size = new System.Drawing.Size(182, 20);
            this.txtGioiTinh.TabIndex = 44;
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangXuat.Location = new System.Drawing.Point(178, 368);
            this.btnDangXuat.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(155, 46);
            this.btnDangXuat.TabIndex = 43;
            this.btnDangXuat.Text = "Đăng Xuất";
            this.btnDangXuat.UseVisualStyleBackColor = true;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnDoiMatKhau
            // 
            this.btnDoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoiMatKhau.Location = new System.Drawing.Point(379, 368);
            this.btnDoiMatKhau.Margin = new System.Windows.Forms.Padding(2);
            this.btnDoiMatKhau.Name = "btnDoiMatKhau";
            this.btnDoiMatKhau.Size = new System.Drawing.Size(155, 46);
            this.btnDoiMatKhau.TabIndex = 42;
            this.btnDoiMatKhau.Text = "Đổi mật khẩu";
            this.btnDoiMatKhau.UseVisualStyleBackColor = true;
            this.btnDoiMatKhau.Click += new System.EventHandler(this.btnDoiMatKhau_Click);
            // 
            // txtPhong
            // 
            this.txtPhong.Location = new System.Drawing.Point(539, 169);
            this.txtPhong.Margin = new System.Windows.Forms.Padding(2);
            this.txtPhong.Name = "txtPhong";
            this.txtPhong.ReadOnly = true;
            this.txtPhong.Size = new System.Drawing.Size(182, 20);
            this.txtPhong.TabIndex = 40;
            // 
            // txtMaToa
            // 
            this.txtMaToa.Location = new System.Drawing.Point(539, 123);
            this.txtMaToa.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaToa.Name = "txtMaToa";
            this.txtMaToa.ReadOnly = true;
            this.txtMaToa.Size = new System.Drawing.Size(182, 20);
            this.txtMaToa.TabIndex = 39;
            // 
            // txtMaSv
            // 
            this.txtMaSv.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtMaSv.Location = new System.Drawing.Point(151, 32);
            this.txtMaSv.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaSv.Name = "txtMaSv";
            this.txtMaSv.ReadOnly = true;
            this.txtMaSv.Size = new System.Drawing.Size(182, 20);
            this.txtMaSv.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(43, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 20);
            this.label7.TabIndex = 28;
            this.label7.Text = "Mã Sinh Viên:";
            // 
            // btnSua
            // 
            this.btnSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.Location = new System.Drawing.Point(566, 368);
            this.btnSua.Margin = new System.Windows.Forms.Padding(2);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(155, 46);
            this.btnSua.TabIndex = 27;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(431, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 20);
            this.label8.TabIndex = 38;
            this.label8.Text = "Mã Phòng:";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(43, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "Họ và Tên:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(151, 76);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(2);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(182, 20);
            this.txtHoTen.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(431, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "CCCD:";
            // 
            // txtCCCD
            // 
            this.txtCCCD.Location = new System.Drawing.Point(539, 79);
            this.txtCCCD.Margin = new System.Windows.Forms.Padding(2);
            this.txtCCCD.Name = "txtCCCD";
            this.txtCCCD.Size = new System.Drawing.Size(182, 20);
            this.txtCCCD.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(431, 122);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 20);
            this.label12.TabIndex = 35;
            this.label12.Text = "Mã Tòa:";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(43, 165);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 20);
            this.label13.TabIndex = 31;
            this.label13.Text = "Giới tính:";
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(539, 32);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(2);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(182, 20);
            this.txtSDT.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(431, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 20);
            this.label14.TabIndex = 34;
            this.label14.Text = "Số Điện thoại:";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(43, 126);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 20);
            this.label15.TabIndex = 32;
            this.label15.Text = "Ngày Sinh:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(151, 208);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(182, 20);
            this.txtDiaChi.TabIndex = 21;
            // 
            // dtpkNgaySinh
            // 
            this.dtpkNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkNgaySinh.Location = new System.Drawing.Point(151, 120);
            this.dtpkNgaySinh.Margin = new System.Windows.Forms.Padding(2);
            this.dtpkNgaySinh.Name = "dtpkNgaySinh";
            this.dtpkNgaySinh.Size = new System.Drawing.Size(182, 20);
            this.dtpkNgaySinh.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(43, 211);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 20);
            this.label16.TabIndex = 33;
            this.label16.Text = "Địa Chỉ";
            // 
            // tabpage5
            // 
            this.tabpage5.Controls.Add(this.btnGiaHan);
            this.tabpage5.Controls.Add(this.tbSoTien);
            this.tabpage5.Controls.Add(this.tbSoKy);
            this.tabpage5.Controls.Add(this.tbMssv);
            this.tabpage5.Controls.Add(this.tbMaPhong);
            this.tabpage5.Controls.Add(this.dtpkTraPhong);
            this.tabpage5.Controls.Add(this.dtpkNhanPhong);
            this.tabpage5.Controls.Add(this.lable32);
            this.tabpage5.Controls.Add(this.label21);
            this.tabpage5.Controls.Add(this.label30);
            this.tabpage5.Controls.Add(this.lable31);
            this.tabpage5.Controls.Add(this.label25);
            this.tabpage5.Controls.Add(this.label26);
            this.tabpage5.Controls.Add(this.label18);
            this.tabpage5.Location = new System.Drawing.Point(4, 22);
            this.tabpage5.Name = "tabpage5";
            this.tabpage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabpage5.Size = new System.Drawing.Size(768, 445);
            this.tabpage5.TabIndex = 4;
            this.tabpage5.Text = "Hợp Đồng";
            this.tabpage5.UseVisualStyleBackColor = true;
            // 
            // btnGiaHan
            // 
            this.btnGiaHan.Location = new System.Drawing.Point(548, 305);
            this.btnGiaHan.Name = "btnGiaHan";
            this.btnGiaHan.Size = new System.Drawing.Size(182, 44);
            this.btnGiaHan.TabIndex = 67;
            this.btnGiaHan.Text = "Gia Hạn";
            this.btnGiaHan.UseVisualStyleBackColor = true;
            this.btnGiaHan.Click += new System.EventHandler(this.btnGiaHan_Click);
            // 
            // tbSoTien
            // 
            this.tbSoTien.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbSoTien.Location = new System.Drawing.Point(548, 232);
            this.tbSoTien.Margin = new System.Windows.Forms.Padding(2);
            this.tbSoTien.Name = "tbSoTien";
            this.tbSoTien.ReadOnly = true;
            this.tbSoTien.Size = new System.Drawing.Size(182, 20);
            this.tbSoTien.TabIndex = 66;
            // 
            // tbSoKy
            // 
            this.tbSoKy.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbSoKy.Location = new System.Drawing.Point(153, 238);
            this.tbSoKy.Margin = new System.Windows.Forms.Padding(2);
            this.tbSoKy.Name = "tbSoKy";
            this.tbSoKy.ReadOnly = true;
            this.tbSoKy.Size = new System.Drawing.Size(182, 20);
            this.tbSoKy.TabIndex = 65;
            // 
            // tbMssv
            // 
            this.tbMssv.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbMssv.Location = new System.Drawing.Point(153, 141);
            this.tbMssv.Margin = new System.Windows.Forms.Padding(2);
            this.tbMssv.Name = "tbMssv";
            this.tbMssv.ReadOnly = true;
            this.tbMssv.Size = new System.Drawing.Size(182, 20);
            this.tbMssv.TabIndex = 64;
            // 
            // tbMaPhong
            // 
            this.tbMaPhong.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbMaPhong.Location = new System.Drawing.Point(153, 188);
            this.tbMaPhong.Margin = new System.Windows.Forms.Padding(2);
            this.tbMaPhong.Name = "tbMaPhong";
            this.tbMaPhong.ReadOnly = true;
            this.tbMaPhong.Size = new System.Drawing.Size(182, 20);
            this.tbMaPhong.TabIndex = 63;
            // 
            // dtpkTraPhong
            // 
            this.dtpkTraPhong.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkTraPhong.Location = new System.Drawing.Point(548, 189);
            this.dtpkTraPhong.Margin = new System.Windows.Forms.Padding(2);
            this.dtpkTraPhong.Name = "dtpkTraPhong";
            this.dtpkTraPhong.Size = new System.Drawing.Size(182, 20);
            this.dtpkTraPhong.TabIndex = 62;
            // 
            // dtpkNhanPhong
            // 
            this.dtpkNhanPhong.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkNhanPhong.Location = new System.Drawing.Point(548, 142);
            this.dtpkNhanPhong.Margin = new System.Windows.Forms.Padding(2);
            this.dtpkNhanPhong.Name = "dtpkNhanPhong";
            this.dtpkNhanPhong.Size = new System.Drawing.Size(182, 20);
            this.dtpkNhanPhong.TabIndex = 61;
            // 
            // lable32
            // 
            this.lable32.Location = new System.Drawing.Point(440, 232);
            this.lable32.Name = "lable32";
            this.lable32.Size = new System.Drawing.Size(103, 20);
            this.lable32.TabIndex = 57;
            this.lable32.Text = "Số tiền:";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(45, 191);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 20);
            this.label21.TabIndex = 51;
            this.label21.Text = "Phòng:";
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(440, 145);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(103, 20);
            this.label30.TabIndex = 52;
            this.label30.Text = "Ngày Nhận Phòng:";
            // 
            // lable31
            // 
            this.lable31.Location = new System.Drawing.Point(440, 185);
            this.lable31.Name = "lable31";
            this.lable31.Size = new System.Drawing.Size(103, 20);
            this.lable31.TabIndex = 56;
            this.lable31.Text = "Ngày Trả Phòng:";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(45, 238);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 20);
            this.label25.TabIndex = 55;
            this.label25.Text = "Số kỳ:";
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(45, 148);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 20);
            this.label26.TabIndex = 54;
            this.label26.Text = "Mã số sinh viên:";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Yellow;
            this.label18.Location = new System.Drawing.Point(3, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(762, 66);
            this.label18.TabIndex = 4;
            this.label18.Text = "Hợp Đồng Thuê Phòng";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dtgvXemThanhVien);
            this.tabPage6.Controls.Add(this.lbxemthanhvien);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(768, 445);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Xem Thành Viên";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dtgvXemThanhVien
            // 
            this.dtgvXemThanhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvXemThanhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvXemThanhVien.Location = new System.Drawing.Point(3, 72);
            this.dtgvXemThanhVien.Name = "dtgvXemThanhVien";
            this.dtgvXemThanhVien.RowHeadersWidth = 51;
            this.dtgvXemThanhVien.Size = new System.Drawing.Size(759, 367);
            this.dtgvXemThanhVien.TabIndex = 6;
            // 
            // lbxemthanhvien
            // 
            this.lbxemthanhvien.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbxemthanhvien.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxemthanhvien.ForeColor = System.Drawing.Color.Yellow;
            this.lbxemthanhvien.Location = new System.Drawing.Point(3, 3);
            this.lbxemthanhvien.Name = "lbxemthanhvien";
            this.lbxemthanhvien.Size = new System.Drawing.Size(762, 66);
            this.lbxemthanhvien.TabIndex = 5;
            this.lbxemthanhvien.Text = "Thành Viên Trong Phòng ";
            this.lbxemthanhvien.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ODL
            // 
            this.ODL.FileName = "openFileDialog1";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(759, 439);
            this.panel4.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 139);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(753, 297);
            this.dataGridView1.TabIndex = 0;
            // 
            // fSinhVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 494);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fSinhVien";
            this.Text = "fXemPhong";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDien)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvNuoc)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvHoaDon)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB)).EndInit();
            this.tabpage5.ResumeLayout(false);
            this.tabpage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvXemThanhVien)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Button btnXemDien;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.ComboBox cbThang;
        private System.Windows.Forms.DataGridView dtgvDien;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtTen2;
        private System.Windows.Forms.DataGridView dtgvNuoc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbThang2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMaPhong2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnXem2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDoiMatKhau;
        private System.Windows.Forms.TextBox txtPhong;
        private System.Windows.Forms.TextBox txtMaToa;
        private System.Windows.Forms.TextBox txtMaSv;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCCCD;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.DateTimePicker dtpkNgaySinh;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.TextBox txtGioiTinh;
        private System.Windows.Forms.PictureBox PB;
        private System.Windows.Forms.Button btnAnh;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAnh;
        private System.Windows.Forms.OpenFileDialog ODL;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cbThang3;
        private System.Windows.Forms.DataGridView dtgvHoaDon;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabpage5;
        private System.Windows.Forms.TextBox tbSoTien;
        private System.Windows.Forms.TextBox tbSoKy;
        private System.Windows.Forms.TextBox tbMaPhong;
        private System.Windows.Forms.DateTimePicker dtpkTraPhong;
        private System.Windows.Forms.DateTimePicker dtpkNhanPhong;
        private System.Windows.Forms.Label lable32;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lable31;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbMssv;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnGiaHan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label lbxemthanhvien;
        private System.Windows.Forms.DataGridView dtgvXemThanhVien;
    }
}